export default {
    language: ["js", "ts", "python"],
    database: ["sqlite", "postgreSql"],
    other: ["html", "css", "sass", "scss", "less", "stylus", "ejs", "jinja", "pug"],
    tool: ["vscode", "nvim", "figma", "git"],
    framework: ["react", "next", "gulp", "express", "flask", "quart"]   
}