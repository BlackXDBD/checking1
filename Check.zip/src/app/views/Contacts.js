import Path from "@/components/Path.js";


export default (t) => {
    return /*html*/ `${Path({ description: t.description })}`;
};
